import React from 'react';

const Pdf = () => {
  return (
    <div>Pdf file</div>
  );
}

export default Pdf;