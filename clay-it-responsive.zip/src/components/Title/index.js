import React from 'react';
import './Title.css';

function Title({title}) {
  return (
    <div className='title'>
      { title }
    </div>
  );
}

export default Title;