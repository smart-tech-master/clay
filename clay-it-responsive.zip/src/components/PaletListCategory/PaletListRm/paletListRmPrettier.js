import React from 'react';

const PaletListRmPrettier = ( { category, data, onClickHandle } ) => {
  return (
    <>
      <div style={{width: '64px', height: '1px'}}></div>
      <div style={{width: '64px', height: '1px'}}></div>
      <div style={{width: '64px', height: '1px'}}></div>
      <div style={{width: '64px', height: '1px'}}></div>
      <div style={{width: '64px', height: '1px'}}></div>
    </>
  );
}

export default PaletListRmPrettier