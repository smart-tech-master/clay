import React from 'react';

const PaletListSmPrettier = ( { category, data, onClickHandle } ) => {
  return (
    <>
      <div style={{width: '49px', height: '1px'}}></div>
      <div style={{width: '49px', height: '1px'}}></div>
      <div style={{width: '49px', height: '1px'}}></div>
      <div style={{width: '49px', height: '1px'}}></div>
      <div style={{width: '49px', height: '1px'}}></div>
      <div style={{width: '49px', height: '1px'}}></div>
      <div style={{width: '49px', height: '1px'}}></div>
      <div style={{width: '49px', height: '1px'}}></div>
      <div style={{width: '49px', height: '1px'}}></div>
      <div style={{width: '49px', height: '1px'}}></div>
      <div style={{width: '49px', height: '1px'}}></div>
      <div style={{width: '49px', height: '1px'}}></div>
      <div style={{width: '49px', height: '1px'}}></div>
      <div style={{width: '49px', height: '1px'}}></div>
      <div style={{width: '49px', height: '1px'}}></div>
    </>
  );
}

export default PaletListSmPrettier