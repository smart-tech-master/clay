import Feature from './feature/reducer';
import Status from './status/reducer';

export default {
  Feature,
  Status,
};