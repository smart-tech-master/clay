class Rect {
  constructor(name, top, left, width, height, backgroundImageSrc) {
    this.name = name;
    this.top = top;
    this.left = left;
    this.width = width;
    this.height = height;
    this.backgroundImageSrc = backgroundImageSrc;
    this.Label = Label;
  }
}