import React, { useState } from 'react';
import Modal from 'react-modal';

// Bind modal to your app element for accessibility
Modal.setAppElement('#root');

const ConfirmModal = () => {
  const [modalIsOpen, setModalIsOpen] = useState(false);

  return (
    <div>
      <Modal
        isOpen={modalIsOpen}
        onRequestClose={() => setModalIsOpen(false)}
        shouldCloseOnOverlayClick={false}
        contentLabel="Example Modal"
        style={{
          overlay: {
            backgroundColor: 'rgba(0, 0, 0, 0.75)'
          },
          content: {
            width: '400px',
            margin: 'auto',
            borderRadius: '0', // No border radius
            padding: '20px',
            textAlign: 'center'
          }
        }}
      >
      </Modal>
    </div>
  );
};

export default ConfirmModal;
